---
name: free-model-delegate
description: Auto-delegate coding and research tasks to free-tier opencode models through an AI scheduler + orchestrator (v2). Trigger automatically on repetitive/mechanical/batch work (multi-file refactors, boilerplate, regex sweeps, test-fixing loops, doc generation) and on explicit requests for free models or named endpoints (GLM-5.2, Nemotron Free, MiniMax M3, big-pickle, deepseek-v4-flash-free, nvidia/*, "用免费模型", offload to opencode). Classifies the task into a DAG, assigns agent roles, routes through capability/quota/history filters via scheduler.py, and executes `opencode run` with timeout + retry + fallback + promotion. Never triggers on one-off trivial questions.
license: MIT
compatibility: claude-code, opencode
metadata:
  audience: developers
  workflow: free-tier-llm-orchestrator
  version: "2.0"
---

# Free-Model Delegate — AI Coding Orchestrator

Schedules coding/research tasks onto free LLMs (NVIDIA build.nvidia.com +
OpenCode Zen free tier) through `opencode run`. Models are execution nodes; the
core is task understanding + scheduling + quality control.

## Architecture (files in this skill dir)

| File | Role |
|---|---|
| `SKILL.md` (this) | Trigger policy + execution loop |
| `orchestrator.md` | Task DAG, role assignment, confidence contract |
| `scheduler.md` | Routing math: filters, scoring, budget, promotion, quota |
| `scheduler.py` | Deterministic computation (scoring/quota/memory) |
| `models.yaml` | Model capability database (verified IDs, promotion tiers) |
| `policies.yaml` | All tunable policies (budgets, thresholds, stages) |
| `extract.py` | Deterministic JSON / confidence-envelope parsing (use this, never hand-roll) |
| `agents/*.md` | Role definitions + prompt templates |
| `test_extract.py` | Unit tests for extract.py (stdlib, offline) |

**On trigger, read `scheduler.md`, `policies.yaml`, and `models.yaml` first.
For multi-stage work also read `orchestrator.md` and the relevant `agents/*.md`.**

## When to trigger

**AUTO-TRIGGER** (repetitive / mechanical / high-volume):
- batch edits/refactors across many files, boilerplate/scaffolding generation
- regex / find-and-replace sweeps, mechanical test-fixing loops
- doc / comment / README / changelog generation
- same-shape tasks run repeatedly (per-module, per-file)

**EXPLICIT trigger**:
- "用免费模型", "免费 AI", "free model", "用免费的"
- "offload", "delegate to opencode", "交给 opencode 跑"
- names a free endpoint: GLM-5.2, Nemotron Free, MiniMax M3, big-pickle,
  deepseek-v4-flash-free, nvidia/*

Do NOT trigger on implicit signals alone (cost concerns, "省点钱", performance
complaints) — confirm first. Do NOT trigger on one-off trivial questions.

## Execution flow (every delegation)

1. **Analyze** — build a Task Profile (scheduler.md §1) and, for normal/critical
   work, a Task DAG (orchestrator.md §1). Estimate tokens from task breadth +
   repo size.
2. **Schedule** — for each DAG node / unit, `python scheduler.py --profile
   <profile.json>` → ordered model chain. Budget from priority.
3. **Execute** — run the loop below with the chain. Inline the role prompt from
   `agents/<role>.md` and upstream stage artifacts into the `opencode run`
   prompt. If the profile risk ≥ `debate.trigger_risk` (or confidence keeps
   failing promotion), run **debate mode** instead: `scheduler.py --debate` →
   independent debaters (rounds 1-2) → judge verdict (see orchestrator.md §5).
4. **Verify** — parse the confidence envelope by contract:
   `python extract.py --envelope <file>` for regular stages,
   `python extract.py --envelope <file> --judge` for judge verdicts,
   `python extract.py --envelope <file> --debater` for debate proposals
   (or import `extract.py` — pass `answer_keys` from `CONTRACTS`).
   NEVER hand-roll extraction: `json.dumps(extract_json(x)) or x` silently
   turns parse failures into the truthy string `"null"`, which then flows
   downstream as a real proposal.
   `confidence < 0.7` → reviewer pass; `< 0.5` → escalate a promotion tier (or
   a debate round).
5. **Record** — `python scheduler.py --record <outcome.json>` (quota + learning
   memory).
6. **Report** — surface the final answer plus a one-line routing decision per
   stage (model, capability match, history, availability).

### Format-violation protocol

Model output follows the JSON contract probabilistically, not deterministically
(long prompts / round-2 injections raise the violation rate). On
`extract_json` → `None` or `envelope.format_violation == true`:

1. **One retry, same model**: append a contract reminder — `"Your previous
   reply did not follow the output contract. Reply with a SINGLE JSON object
   only (no markdown fences, no prose)."` — within budget. Fall through to the
   next chain model if it still violates.
2. **Mark the violation**: pass the artifact DOWNSTREAM as raw text (the
   envelope's `raw` field carries the original model output), tagged
   `format_violation: true`, and treat its confidence as
   `min(parsed["confidence"], 0.5)` (on parse failure `extract_envelope`
   already returns 0.0, which satisfies the cap). `raw` is for hand-off and
   debugging ONLY — do not persist it into `--record` or state files.
   Never fabricate a parsed structure where none exists.
3. **Judge/verify guard**: a null / unparsed proposal is grounds to reject or
   rule for the other side — never to build a verdict on the placeholder.

## Scheduler invocation

```bash
# resolve a chain for one unit
python scheduler.py --profile profile.json --skill-dir <skill_dir> --state-dir ~/.config/free-model-delegate

# record the outcome (updates quota + memory)
python scheduler.py --record outcome.json --skill-dir <skill_dir> --state-dir ~/.config/free-model-delegate
```

`<skill_dir>` = this skill's directory. If Python/PyYAML is missing, fall back
to the static chain in `policies.yaml → fallback_chain` and update state by
hand per scheduler.md §5.

## Execution loop

Wrap every delegation in this loop (bash): per-attempt timeout, exponential
backoff, error classification, chain fallback.

```bash
WORKDIR="/path/to/project"
PROMPT="Add a /healthz endpoint that returns {status:'ok'}"
TIMEOUT_SECS=600            # wall-clock cap per attempt
# Chain from scheduler.py (task-aware order, budget-capped). Example only:
MODELS=(
  "nvidia/deepseek-ai/deepseek-v4-flash"
  "nvidia/minimaxai/minimax-m3"
  "nvidia/z-ai/glm-5.2"
  "opencode/deepseek-v4-flash-free"
  "opencode/big-pickle"
  "opencode/nemotron-3-ultra-free"
  "opencode/hy3-free"
)
MAX_ATTEMPTS=2              # retries per model before moving on
BASE_BACKOFF=2              # seconds; doubles each attempt (2s, 4s, …)

attempt_total=0
for model in "${MODELS[@]}"; do
  for attempt in $(seq 1 $MAX_ATTEMPTS); do
    attempt_total=$((attempt_total+1))
    echo "→ [$model] attempt $attempt (overall #$attempt_total)" >&2

    out=$(timeout "$TIMEOUT_SECS" opencode run \
        --auto --dir "$WORKDIR" --model "$model" --format json \
        "$PROMPT" 2>&1)
    code=$?

    if [ $code -eq 0 ]; then
      answer=$(echo "$out" | jq -r 'select(.type=="text") | .part.text // empty' \
               | tail -1)
      if [ -n "$answer" ]; then
        printf '%s\n' "$answer"
      else
        echo "$out"
      fi
      exit 0
    fi

    if [ $code -eq 124 ]; then
      reason="timeout after ${TIMEOUT_SECS}s"; transient=true
    elif echo "$out" | grep -qiE '429|rate.?limit|quota|too.?many.?requests|exceeded'; then
      reason="rate limit / quota"; transient=true
    elif echo "$out" | grep -qiE '\b(5[0-9]{2}|502|503|504)\b|connection.?reset|upstream.?timeout|bad.?gateway|service.?unavailable'; then
      reason="upstream 5xx / network"; transient=true
    elif echo "$out" | grep -qiE '\b(401|403|404)\b|unauthor|invalid.?api.?key|model.?not.?found|forbidden'; then
      reason="auth / not-found (permanent)"; transient=false
    else
      reason="unknown (exit $code)"; transient=true
    fi

    echo "  ✗ [$model] $reason" >&2
    if [ "$transient" = false ]; then
      break
    fi
    if [ $attempt -lt $MAX_ATTEMPTS ]; then
      sleep $((BASE_BACKOFF ** attempt))
    fi
  done
done

echo "All models in chain exhausted after $attempt_total attempts" >&2
exit 1
```

### PowerShell port (native Windows, non-Git-Bash)

Verified on PowerShell 5.1. Two gotchas handled here:
opencode ships as an npm shim (`opencode.cmd`), so it must be launched via
`cmd.exe /c`; and `ProcessStartInfo.ArgumentList` does NOT exist in .NET
Framework (PS 5.1) — build the argument string manually.

```powershell
$WORKDIR  = "C:\path\to\project"
$PROMPT   = "Add a /healthz endpoint that returns {status:'ok'}"
$TIMEOUT  = 600   # seconds
$MODELS   = @('nvidia/deepseek-ai/deepseek-v4-flash','nvidia/minimaxai/minimax-m3','nvidia/z-ai/glm-5.2','opencode/deepseek-v4-flash-free','opencode/big-pickle','opencode/nemotron-3-ultra-free','opencode/hy3-free')
$MAX      = 2
$BACKOFF  = 2

foreach ($model in $MODELS) {
  for ($a = 1; $a -le $MAX; $a++) {
    Write-Host "→ $model attempt $a"
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'cmd.exe'
    $psi.Arguments = '/c opencode run --auto --dir "' + $WORKDIR +
      '" --model ' + $model + ' --format json "' + $PROMPT + '"'
    $psi.WorkingDirectory = $WORKDIR
    $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $p = [System.Diagnostics.Process]::Start($psi)
    $exited = $p.WaitForExit($TIMEOUT * 1000)
    if (-not $exited) { $p.Kill(); $code = 124 } else { $code = $p.ExitCode }
    $out = $p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd()

    if ($code -eq 0) {
      $last = ($out -split "`n" | Where-Object { $_ -match '"type"\s*:\s*"text"' } | Select-Object -Last 1)
      if ($last) { ($last | ConvertFrom-Json).part.text } else { $out }
      return
    }
    $transient = $true
    if ($code -eq 124) { $reason = "timeout" }
    elseif ($out -match '429|rate.?limit|quota|exceeded') { $reason = "rate limit / quota" }
    elseif ($out -match '5\d\d|connection.?reset|upstream') { $reason = "upstream" }
    elseif ($out -match '401|403|404|unauthor|invalid.?key|model.?not.?found') { $reason = "permanent"; $transient = $false }
    else { $reason = "unknown exit $code" }
    Write-Host "  ✗ $model $reason"
    if (-not $transient) { break }
    if ($a -lt $MAX) { Start-Sleep -Seconds ([math]::Pow($BACKOFF, $a)) }
  }
}
Write-Error "All models in chain exhausted"
exit 1
```

## Multi-turn continuation

Reuse a session across stages:

```bash
SESSION=$(opencode run --auto --dir . --model opencode/big-pickle --format json \
  "List the failing tests in tests/" 2>&1 | jq -r 'select(.type=="session") | .sessionID' | head -1)
opencode run --auto --dir . --model opencode/big-pickle --format json \
  -s "$SESSION" "Fix the first failure"
```

## One-time setup

```bash
opencode auth login -p nvidia        # key from https://build.nvidia.com
# Zen: /connect -> OpenCode Zen -> paste key from https://opencode.ai/auth
python scheduler.py --init --skill-dir <skill_dir>   # create state files
opencode models nvidia --refresh && opencode models opencode --refresh
```

Verify: `opencode auth list`. State lives at
`~/.config/free-model-delegate/` (quota.yaml + memory/).

## Guardrails recap

- **free_only: true** — never touch `cost: paid` models without explicit approval.
- **Budget is a hard cap** — low=1 / normal=2 / critical=4 distinct models per task.
- **Layered timeouts** — inner `timeout` ≤ outer Bash-tool timeout.
- **`--auto` grants full bash+edit power in `--dir`** — sanity-check `--dir`.
- **Free-tier data retention** — no secrets, tokens, or PII into free endpoints.
- **Record every outcome** — without scheduler.py `--record`, the learning
  router and quota state go stale.
- **Recursion** — opencode also loads this skill; disable with
  `OPENCODE_DISABLE_CLAUDE_CODE_SKILLS=1` if undesired.
