#!/usr/bin/env python3
"""Unit tests for extract.py — extraction ladder + envelope defaults.

Run: python test_extract.py   (stdlib unittest, no deps)
"""

import json
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True  # keep the skill dir clean of __pycache__/pyc
sys.path.insert(0, str(Path(__file__).resolve().parent))
from extract import extract_json, extract_envelope, CONTRACTS

JUDGE = CONTRACTS["judge"]
DEBATER = CONTRACTS["debater"]


class TestExtractJson(unittest.TestCase):
    def test_none_and_empty(self):
        self.assertIsNone(extract_json(None))
        self.assertIsNone(extract_json(""))
        self.assertIsNone(extract_json("   \n  "))

    def test_whole_text_json(self):
        x = '{"proposal": "a", "confidence": 0.8}'
        self.assertEqual(extract_json(x), {"proposal": "a", "confidence": 0.8})

    def test_prose_around_json(self):
        x = '我的方案如下: {"proposal": "b", "confidence": 0.7} \n以上就是全部内容'
        self.assertEqual(extract_json(x), {"proposal": "b", "confidence": 0.7})

    def test_json_first_in_long_prose(self):
        x = '{"a": 1} 接下来还有一些补充说明和讨论...'
        self.assertEqual(extract_json(x), {"a": 1})

    def test_fenced_json_block(self):
        x = "```json\n{\"proposal\": \"c\", \"confidence\": 0.6}\n```"
        self.assertEqual(extract_json(x), {"proposal": "c", "confidence": 0.6})

    def test_free_text_only(self):
        self.assertIsNone(extract_json("我仔细分析了这个问题,结论是采用方案 A。"))

    def test_literal_null_string(self):
        self.assertIsNone(extract_json("null"))

    def test_unbalanced_braces_falls_through(self):
        x = "这里有残缺的花括号 {proposal: broken, confidence: 0.5}"
        self.assertIsNone(extract_json(x))

    def test_brace_inside_string_value(self):
        x = '{"proposal": "use } careful", "confidence": 0.7}'
        self.assertEqual(extract_json(x),
                         {"proposal": "use } careful", "confidence": 0.7})

    def test_open_brace_inside_string_value(self):
        x = '{"a": "x { y", "b": 1} 尾巴文本'
        self.assertEqual(extract_json(x), {"a": "x { y", "b": 1})

    def test_escaped_quote_inside_string(self):
        x = '{"proposal": "say \\"hi\\" { not a brace", "confidence": 0.6}'
        self.assertEqual(extract_json(x)["proposal"], 'say "hi" { not a brace')

    def test_prose_with_brace_chars_before_json(self):
        x = '一般说明 { 结构标记 } 然后: {"real": "json"}'
        self.assertEqual(extract_json(x), {"real": "json"})


class TestOldBugRegression(unittest.TestCase):
    """The exact bug that shipped 'null' proposals downstream:
    json.dumps(extract_json(x)) or x — json.dumps(None) == 'null' (truthy),
    so the fallback never ran. New code MUST use `is not None`."""

    def test_json_dumps_none_is_truthy(self):
        self.assertEqual(json.dumps(None), "null")
        self.assertTrue(json.dumps(None))  # the trap

    def test_correct_guard_keeps_raw_text(self):
        x = "自由文本,不是 JSON"
        parsed = extract_json(x)
        result = json.dumps(parsed, ensure_ascii=False) if parsed is not None else x
        self.assertEqual(result, x)  # raw text preserved, NOT "null"

    def test_parsed_value_serializes_normally(self):
        x = '{"proposal": "ok"}'
        parsed = extract_json(x)
        result = json.dumps(parsed, ensure_ascii=False) if parsed is not None else x
        self.assertEqual(result, '{"proposal": "ok"}')


class TestExtractEnvelope(unittest.TestCase):
    def test_valid_envelope_passthrough(self):
        x = '{"answer": "done", "confidence": 0.87, "risk": "medium", "need_review": false}'
        e = extract_envelope(x)
        self.assertEqual(e["answer"], "done")
        self.assertEqual(e["confidence"], 0.87)
        self.assertEqual(e["risk"], "medium")
        self.assertFalse(e["need_review"])
        self.assertFalse(e["format_violation"])
        self.assertEqual(e["raw"], x)

    def test_missing_envelope_defaults(self):
        x = "no json here at all"
        e = extract_envelope(x)
        self.assertEqual(e["confidence"], 0.0)
        self.assertEqual(e["risk"], "unknown")
        self.assertTrue(e["need_review"])
        self.assertTrue(e["format_violation"])
        self.assertEqual(e["answer"], x)  # raw preserved as answer on parse failure
        self.assertEqual(e["raw"], x)

    def test_literal_null_envelope(self):
        e = extract_envelope("null")
        self.assertTrue(e["format_violation"])
        self.assertEqual(e["confidence"], 0.0)

    def test_confidence_clamped(self):
        self.assertEqual(extract_envelope('{"confidence": 1.5}')["confidence"], 1.0)
        self.assertEqual(extract_envelope('{"confidence": -1}')["confidence"], 0.0)

    def test_confidence_invalid_is_violation(self):
        e = extract_envelope('{"answer": "x", "confidence": "high"}')
        self.assertEqual(e["confidence"], 0.0)
        self.assertTrue(e["format_violation"])  # invalid value -> same path as null/missing
        self.assertTrue(e["need_review"])

    def test_confidence_numeric_string_ok(self):
        e = extract_envelope('{"answer": "x", "confidence": "0.77"}')
        self.assertEqual(e["confidence"], 0.77)
        self.assertFalse(e["format_violation"])

    def test_partial_envelope_is_violation(self):
        e = extract_envelope('{"confidence": 0.9}')
        self.assertTrue(e["format_violation"])  # missing "answer" key

    def test_unknown_risk(self):
        e = extract_envelope('{"risk": "extreme"}')
        self.assertEqual(e["risk"], "unknown")

    def test_judge_format_not_violation(self):
        x = ('{"decision": "adopt plan A", "verdict": "a", "scores": {}, '
             '"reasons": ["safer"], "risk": "low", "confidence": 0.8}')
        e = extract_envelope(x, answer_keys=JUDGE)
        self.assertEqual(e["answer"], "adopt plan A")
        self.assertEqual(e["confidence"], 0.8)
        self.assertFalse(e["format_violation"])
        self.assertFalse(e["need_review"])  # judge verdict is terminal — no re-review

    def test_judge_explicit_need_review_wins(self):
        x = ('{"decision": "adopt plan A", "verdict": "merged", '
             '"confidence": 0.6, "need_review": true}')
        self.assertTrue(extract_envelope(x, answer_keys=JUDGE)["need_review"])

    def test_judge_format_missing_confidence_is_violation(self):
        x = '{"decision": "adopt plan A", "verdict": "a"}'
        e = extract_envelope(x, answer_keys=JUDGE)
        self.assertTrue(e["format_violation"])
        self.assertEqual(e["confidence"], 0.0)

    def test_debater_contract_not_violation(self):
        x = ('{"proposal": "方案 A:先写测试", "rationale": ["理由1"], '
             '"rebuttal": "", "confidence": 0.75}')
        e = extract_envelope(x, answer_keys=DEBATER)
        self.assertEqual(e["answer"], "方案 A:先写测试")
        self.assertFalse(e["format_violation"])
        self.assertTrue(e["need_review"])  # debater is NOT the terminal gate

    def test_debater_under_default_keys_is_strict(self):
        x = '{"proposal": "方案 A", "confidence": 0.75}'
        e = extract_envelope(x)  # default = stage contract ("answer",)
        self.assertTrue(e["format_violation"])  # contract mixing flagged, not accepted

    def test_regular_stage_emitting_judge_shape_is_violation(self):
        e = extract_envelope('{"decision": "x", "confidence": 0.8}')
        self.assertTrue(e["format_violation"])  # strict default: no lenient superset

    def test_verdict_key_alone_is_not_terminal(self):
        e = extract_envelope('{"answer": "x", "verdict": "a", "confidence": 0.8}')
        self.assertFalse(e["format_violation"])
        self.assertTrue(e["need_review"])  # "verdict" hash alone must not skip review

    def test_custom_answer_keys(self):
        x = '{"verdict_body": "ok", "confidence": 0.6}'
        e = extract_envelope(x, answer_keys=("verdict_body",))
        self.assertEqual(e["answer"], "ok")
        self.assertFalse(e["format_violation"])
        self.assertTrue(extract_envelope(x)["format_violation"])  # default keys

    def test_null_answer_value_normalized(self):
        e = extract_envelope('{"answer": null, "confidence": 0.8}')
        self.assertEqual(e["answer"], "")
        self.assertTrue(e["format_violation"])
        self.assertTrue(e["need_review"])

    def test_null_confidence_is_violation(self):
        e = extract_envelope('{"answer": "x", "confidence": null}')
        self.assertEqual(e["confidence"], 0.0)
        self.assertTrue(e["format_violation"])
        self.assertTrue(e["need_review"])

    def test_null_need_review_is_conservative(self):
        e = extract_envelope('{"answer": "x", "confidence": 0.8, "need_review": null}')
        self.assertTrue(e["need_review"])
        self.assertFalse(e["format_violation"])

    def test_string_false_need_review_parsed(self):
        e = extract_envelope('{"answer": "x", "confidence": 0.8, "need_review": "false"}')
        self.assertFalse(e["need_review"])

    def test_string_true_need_review_parsed(self):
        e = extract_envelope('{"answer": "x", "confidence": 0.8, "need_review": "true"}')
        self.assertTrue(e["need_review"])

    def test_ambiguous_string_need_review_conservative(self):
        e = extract_envelope('{"answer": "x", "confidence": 0.8, "need_review": "maybe"}')
        self.assertTrue(e["need_review"])  # ambiguous -> over-review, never skip

    def test_blank_string_answer_is_violation(self):
        e = extract_envelope('{"answer": "", "confidence": 0.8}')
        self.assertTrue(e["format_violation"])

    def test_raw_preserved_on_violation(self):
        x = '{"answer": "", "confidence": 0.8}'
        e = extract_envelope(x)
        self.assertTrue(e["format_violation"])
        self.assertEqual(e["raw"], x)

    def test_regular_stage_missing_need_review_is_conservative(self):
        e = extract_envelope('{"answer": "done", "confidence": 0.9}')
        self.assertTrue(e["need_review"])  # absent key -> review required
        self.assertFalse(e["format_violation"])


if __name__ == "__main__":
    unittest.main(verbosity=2)