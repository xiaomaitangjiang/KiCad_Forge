# Scheduler Engine — AI Router for Free-Model Delegate (v2)

This file describes the routing math. **The math is executed by
`scheduler.py`** — the agent only builds the Task Profile (a judgment call),
passes it to the script, and receives an ordered model chain back. Do not
hand-compute scores.

Load `models.yaml` + `policies.yaml` alongside this file.

## 0. Pipeline overview

```
user request
   │
   ▼
Task Analyzer ──► Task Profile (category, requirements, risk, tokens, priority)
   │                     (agent judgment)
   ▼
scheduler.py choose()
   ├─ Capability Filter    (capability_match ≥ min_capability_match)
   ├─ Context Filter       (tokens vs long_context)
   ├─ Tool Support Filter  (tool_calling ≥ min_tool_calling, unless pure Q&A)
   ├─ Rate Limit Filter    (rpm used vs rpm_limit)
   ├─ Health Filter        (circuit breaker: cooldown/error dropped)
   ├─ Twin resolution      (flip NVIDIA→Zen twin when nvidia-day-1000 exhausted)
   └─ Scoring              score = task_match×0.4 + success_history×0.25
                                          + speed×0.15 + availability×0.20
   │
   ▼
Ordered chain (length ≤ priority budget) + promotion ladder
   │
   ▼
SKILL.md execution loop (timeout + retry + fallback along the chain)
   │
   ▼
scheduler.py record()  ──► quota.yaml + memory (learning router)
```

## 1. Task Analyzer

Produce a Task Profile (YAML or JSON). Only set dimensions that matter.

```yaml
task:
  category: coding.bugfix        # from the classification tree
  requirements:                  # 0-10 each
    reasoning: 8
    coding: 9
    context: 7
    speed: 6
    tool_use: 8
  risk: medium                   # low | medium | high
  tokens_estimated: 12000
  priority: normal               # low | normal | critical
  stage_needs_tools: true        # false for pure Q&A/planning
```

Requirement mapping: `coding→coding`, `reasoning→reasoning`,
`context→long_context`, `speed→speed`, `tool_use→tool_calling`.

### Classification tree

```
Coding
├── New Feature
├── Bug Fix
├── Refactor
├── Review
├── Test
└── Documentation

Reasoning
├── Architecture
├── Algorithm
└── Security

Analysis
├── Logs
├── Repository
└── Requirements
```

## 2. Filters (all in scheduler.py)

1. **Capability** — `capability_match` = mean of `min(cap, req)/req` over
   required dims (missing dim → 0). Drop if `< min_capability_match`.
2. **Context** — estimate from `long_context`: <6→8K, 6→32K, 7→64K, 8→128K,
   9→256K, 10→512K. Drop if `tokens_estimated` exceeds it.
3. **Tool support** — drop if `tool_calling < min_tool_calling`, unless the
   stage is pure Q&A/planning (`stage_needs_tools: false`).
4. **Rate limit** — `availability = max(0, 1 − used_minute/rpm_limit)`.
5. **Health** — `status=cooldown` (until not expired) or `status=error` → drop.

**Twin resolution:** when `nvidia-day-1000.used ≥ limit`, every NVIDIA model
flips to its `twin` (Zen). Twins are the same capability — never count both
toward budget.

## 3. Scoring (v2 formula)

```
score = capability_match × 0.4
      + success_history  × 0.25
      + speed_norm       × 0.15     (speed/10)
      + availability     × 0.20
```

`success_history` comes from the learning router memory
(`model-performance.json`); neutral value 0.5 when no history.

Example (task: debugging, `coding 9 debugging 9`):

| Model | cap_match | history | speed | avail | score |
|---|---|---|---|---|---|
| deepseek_v4_flash | 9.0 | 0.8 | 1.0 | 0.9 | 3.60+0.20+0.15+0.18 = **4.13** |
| nemotron_ultra | 8.0 | 0.5 | 0.4 | 0.1 | 3.20+0.125+0.06+0.02 = 3.41 |

→ DeepSeek wins: quota + history outweigh raw capability.

## 4. Promotion ladder (Kubernetes-style escalation)

Tiers from `policies.yaml`. The scheduler returns the top `budget` scored
models, then appends the promotion ladder (highest tier first) so the
execution loop can escalate when a low model fails or reports low confidence.

```
simple  → hy3, step_37_flash, nemotron_nano, mimo
normal  → deepseek_v4_flash(+zen), nemotron_lightning(+zen), laguna, minimax_m27, qwen_coder_32b, gpt_oss_20b
complex → big_pickle, glm_52, minimax_m3, qwen_coder, nemotron_super, gpt_oss_120b, mistral_medium_35
critical→ nemotron_ultra(+zen), deepseek_v4_pro, kimi_k2
```

Escalation rules (enforced by the agent in orchestrator.md):
- model fails (permanent error) → next model in chain, then next tier
- `confidence < self_escalate (0.5)` → escalate one tier before the next attempt
- budget is a hard cap: escalation may not exceed `by_priority` budget

## 5. Quota state, circuit breaker, budgets

State lives in `~/.config/free-model-delegate/` (created by
`python scheduler.py --init`):

```
quota.yaml
  pools: nvidia-day-1000 {limit, used}          # NVIDIA global 1000 req/day
  budgets: per-category daily caps               # from policies.yaml
  models: <name>: {used_minute, failures, status, cooldown_until}
memory/
  model-performance.json                         # learning router data
  task-history.json                              # raw history log
```

### Update rules (scheduler.py record())

| Outcome | Update |
|---|---|
| success | `used_minute+1`; `failures=0`; `status=healthy`; NVIDIA pool `used+1` |
| 429 / quota | `failures+1`; 1st → `warning`; 2nd+ → `cooldown` 10m |
| 5xx / timeout | `failures+1`; 3rd → `cooldown` 10m |
| 401/403/404 | `status=error` (permanent until user re-auths) |

### Circuit breaker

```
HEALTHY ──1×429──► WARNING ──2nd consecutive 429──► COOLDOWN (10m)
   ▲                                                     │
   └────────────── success resets ───────────────────────┘
ERROR: 401/403/404 → permanent until re-auth
```

### Token Budget Manager

`budgets.daily` caps requests per category (reasoning/coding/analysis/cheap).
When a category budget is exhausted, the scheduler drops heavy models for that
category and routes to the `cheap` pool. (Enforced in scheduler.py by category;
agents should prefer budget-conscious models when a category is nearly spent.)

## 6. CLI usage

```bash
# initialize state (first run)
python scheduler.py --init --skill-dir <skill> --state-dir ~/.config/free-model-delegate

# choose a chain for a task profile (profile.json)
python scheduler.py --profile profile.json --skill-dir <skill>

# debate mode: independent debaters + judge for high-risk tasks
python scheduler.py --debate profile.json --skill-dir <skill>

# record an outcome (outcome.json) — feeds quota + learning memory
python scheduler.py --record outcome.json --skill-dir <skill>

# look up learned success rate
python scheduler.py --history <model> <category> --skill-dir <skill>

# validate configs
python scheduler.py --self-check --skill-dir <skill>
```

Profile JSON:

```json
{
  "category": "coding.bugfix",
  "requirements": {"reasoning": 8, "coding": 9, "context": 7, "speed": 6, "tool_use": 8},
  "risk": "medium",
  "tokens_estimated": 12000,
  "priority": "normal",
  "stage_needs_tools": true
}
```

Outcome JSON:

```json
{
  "model": "deepseek_v4_flash",
  "result": "success",
  "category": "coding.bugfix",
  "task": "fix null deref",
  "rating": 5,
  "tokens": 3000
}
```

`result` ∈ success | rate_limit | quota | timeout | upstream | auth | not_found | permanent

## 7. Guardrails

- **free_only: true by default** — `cost: paid` (e.g. kimi_k2) never selected
  without explicit user approval. If free_only blocks everything, say so.
- **Budget is a hard cap** — `low=1 / normal=2 / critical=4` distinct models.
- **NVIDIA pool is global** — `used ≥ limit` disables every NVIDIA model; route
  to Zen twins without trying NVIDIA first.
- **Never retry a model in `error` state.**
- **Report the routing line** — model, capability_match, history, availability.
