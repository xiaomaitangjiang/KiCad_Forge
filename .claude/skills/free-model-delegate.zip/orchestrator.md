# Orchestrator — Task DAG, Roles, Confidence Contract

This is the coordination layer. It decides WHAT to do and in what ORDER; the
scheduler decides WHICH model does each unit; the agent executes each unit via
`opencode run`.

The orchestrator is executed by the LLM agent following these rules. Keep
templates in `agents/*.md` — load one per stage and inline it into the stage
prompt.

## 1. Task DAG Generator

Do not map "task → model". Map "task → DAG of typed units → role per unit → model
per role".

For a critical/normal task, emit a DAG before any execution:

```yaml
task:
  name: payment_system
  DAG:
    - id: architecture      type: design
    - id: database          type: schema
    - id: api               type: coding
    - id: security          type: review
    - id: test              type: testing
  dependencies:
    database: [architecture]
    api:      [database]
    test:     [api]
```

Rules:
- A node may run once all its `dependencies` completed successfully.
- Independent branches may run in parallel **only if** `policies.yaml →
  parallel.enabled` is true (phase 2; currently false → serialize topologically).
- Each node gets a role (planner/coder/debugger/reviewer/tester/synthesizer)
  and is delegated as ONE `opencode run` (see SKILL.md loop).
- Node output is a `stage_artifact` passed into dependent nodes' prompts.
- Every node and the whole task must respect the budget (distinct models
  consumed across all nodes ≤ `by_priority` budget).

### Stage templates (from policies.yaml `stages`)

| Task | Planner | Coder | Tester | Reviewer |
|---|---|---|---|---|
| new_feature | big_pickle | deepseek_v4_flash | hy3 | nemotron_ultra |
| bugfix | (debugger) laguna | deepseek_v4_flash | — | big_pickle |
| architecture | nemotron_ultra | — | — | big_pickle |

The scheduler may override the template model based on quota/history; treat the
template as a strong hint, the scheduler output as the decision.

## 2. Agent Role System

Every stage runs with an agent role loaded from `agents/<role>.md`. Roles
constrain behavior:

| Role | File | Responsibilities | Model bias |
|---|---|---|---|
| Architect / Planner | `agents/planner.md` | design, tech choice, tradeoffs, risks; **no code** | nemotron_ultra, big_pickle |
| Coder | `agents/coder.md` | implement exactly, minimal diff | deepseek_v4_flash, nemotron_lightning |
| Debugger | `agents/debugger.md` | reproduce → isolate → hypothesis; **do not fix** | laguna, nemotron_lightning |
| Reviewer | `agents/reviewer.md` | bugs, security, maintainability | big_pickle, nemotron_ultra |
| Debater | `agents/debater.md` | independent proposal + rebuttal (debate mode) | top-2 distinct models from scheduler |
| Judge | `agents/judge.md` | arbitrate debate, verdict + confidence (debate mode) | `judge_models` chain |

Each role loads its prompt template, which is prefixed to the actual task text
inside the `opencode run` prompt. This keeps model behavior role-scoped without
defining opencode agents.

## 3. Confidence Contract

Every stage must return a confidence envelope (JSON, last text block):

```json
{ "answer": "...", "confidence": 0.87, "risk": "medium", "need_review": true }
```

Enforcement (agent-level):
- Parse the envelope with `extract.py` by contract:
  `python extract.py --envelope <file>` (regular stages),
  `--envelope <file> --judge` (judge verdicts, key "decision"),
  `--envelope <file> --debater` (debate proposals, key "proposal").
  Do not hand-roll parsing —
  `json.dumps(extract_json(x)) or x` is buggy: `json.dumps(None)` yields the
  truthy string `"null"`, which then flows downstream as a real artifact.
- `confidence < review_threshold (0.7)` → mandatory reviewer pass before the
  artifact can feed dependent nodes.
- `confidence < self_escalate (0.5)` → escalate one promotion tier and re-run
  the stage (budget permitting).
- No envelope parsed → `extract_envelope` returns `confidence: 0.0,
  need_review: true, format_violation: true`; treat as review-required.
- Format violation (`format_violation: true`): one contract-retry with the
  same model ("Reply with a SINGLE JSON object only"), then pass the raw text
  downstream tagged `format_violation: true` with confidence capped at 0.5.

## 4. Promotion & failure handling

Escalation is driven by the scheduler's chain + promotion ladder. When a stage
fails or is low-confidence:

```
fail/low-conf → next model in chain → next promotion tier → give up (budget cap)
```

- Permanent errors (auth/404) skip the model, do not retry.
- Transient (429/5xx/timeout): SKILL.md loop retries with backoff first.
- Escalation consumes budget; if budget is exhausted, stop and hand a partial
  summary + the failure reason to the user.

## 5. Multi-model debate

**Trigger** (`policies.yaml → debate`): risk ≥ `trigger_risk` (high), OR a
stage's confidence stays < 0.5 after promotion (escalate to debate instead of
re-running the same tier), OR the user explicitly asks ("debate", "让两个模型
辩论"). Enabled by default via `debate.enabled: true`.

**Team** — resolved by `scheduler.py --debate <profile.json>`:
- `debaters`: N distinct models (default 2). Twins (same-source, e.g.
  deepseek_v4_flash + its zen twin) are never both picked — same source ≠
  independent opinion.
- `judge`: first available model from `judge_models` preference chain, else the
  strongest available model not already debating.

**Sequence**:
1. Round 1 — each debater produces an independent proposal (separate sessions,
   `agents/debater.md` role, parallel `opencode run`s).
2. Round 2 (if `rounds ≥ 2`) — swap proposals; each debater rebuts + revises.
3. Judge reviews both final proposals (`agents/judge.md`), re-runs cheap
   verification itself, and issues the verdict:
   `{ "decision", "verdict": a|b|merged|reject, "confidence", "risk" }`.
   A proposal that failed JSON parsing (null / unparsable) is treated as a
   NON-answer: the judge rules for the other side or `reject` — never builds a
   verdict on the placeholder.
4. Confidence contract applies to the judge output:
   - `confidence ≥ 0.7` → decision is final, feed dependent nodes.
   - `0.5 ≤ confidence < 0.7` → one reviewer pass on the decision.
   - `confidence < 0.5` → escalate: one more debate round, or promotion tier,
     budget permitting.
   - `verdict: reject` → re-plan the task, do not re-debate.
5. Record every participant (each debater + judge) via `scheduler.py --record`.

**Budget**: debate consumes `debaters + judge` distinct models. Cap = normal
budget × `budget_multiplier` (e.g. critical 4 × 1.5 = 6). Stop when exceeded.

## 6. Orchestrator flow (per delegation)

1. Analyze → Task Profile (scheduler.md §1) + DAG.
2. Topological order of ready nodes; for each:
   a. assign role, load `agents/<role>.md` template
   b. scheduler.py `--profile` (node requirements) → model chain
   c. execute via SKILL.md loop, inline role prompt + upstream artifacts
   d. parse confidence envelope; review/escalate if needed
   e. scheduler.py `--record` the outcome
   f. store `stage_artifact` for dependents
3. Final: merge terminal artifacts, summarize for the user with the routing
   line from each stage.
