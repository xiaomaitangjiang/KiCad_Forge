#!/usr/bin/env python3
"""scheduler.py — deterministic computation for the Free-Model Delegate skill.

The LLM agent makes JUDGMENT calls (task profile, DAG, quality assessment);
this script does the MATH (scoring, quota accounting, memory updates) so
scores are reproducible and state files never get corrupted by hand edits.

Usage:
  python scheduler.py --profile <profile.json>            # choose a model chain
  python scheduler.py --debate <profile.json>             # debaters + judge for high-risk tasks
  python scheduler.py --record <outcome.json>             # update quota + memory
  python scheduler.py --init                              # create state files
  python scheduler.py --self-check                        # validate everything
  python scheduler.py --history <category> <model>        # success-rate lookup

All paths default to the skill directory (models.yaml, policies.yaml) and
~/.config/free-model-delegate/ (runtime state). Override with --skill-dir
and --state-dir.
"""

import argparse
import json
import math
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

try:
    import yaml
except ImportError:
    print("FATAL: PyYAML required (pip install pyyaml)", file=sys.stderr)
    sys.exit(2)

SKILL_DIR = Path(__file__).resolve().parent
DEFAULT_STATE_DIR = Path.home() / ".config" / "free-model-delegate"

FALLBACK_MODELS = [
    "deepseek_v4_flash",
    "minimax_m3",
    "glm_52",
    "deepseek_v4_flash_zen",
    "big_pickle",
    "nemotron_ultra_zen",
    "hy3",
]

CONTEXT_ESTIMATE = {0: 8192, 6: 32768, 7: 65536, 8: 131072, 9: 262144, 10: 524288}


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def load_yaml(path: Path):
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_json(path: Path):
    if not path.exists():
        return {}
    raw = path.read_bytes()
    if raw.startswith(b"\xef\xbb\xbf"):  # strip UTF-8 BOM (PS 5.1 Set-Content)
        raw = raw[3:]
    return json.loads(raw.decode("utf-8"))


def save_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_state(state_dir: Path):
    quota = load_yaml(state_dir / "quota.yaml")
    perf = load_json(state_dir / "memory" / "model-performance.json")
    history = load_json(state_dir / "memory" / "task-history.json")
    return quota, perf, history


def init_state(state_dir: Path, models: dict, policies: dict):
    state_dir.mkdir(parents=True, exist_ok=True)
    memdir = state_dir / "memory"
    memdir.mkdir(parents=True, exist_ok=True)

    quota = {
        "version": 2,
        "free_only": policies.get("free_only", True),
        "pools": {"nvidia-day-1000": {"limit": 1000, "used": 0}},
        "budgets": policies.get("budgets", {}),
        "models": {},
    }
    for name, m in models.items():
        quota["models"][name] = {
            "used_minute": 0,
            "failures": 0,
            "status": "healthy",
            "cooldown_until": None,
        }
    save_yaml(state_dir / "quota.yaml", quota)

    if not (memdir / "model-performance.json").exists():
        save_json(memdir / "model-performance.json", {"version": 1, "records": {}})
    if not (memdir / "task-history.json").exists():
        save_json(memdir / "task-history.json", {"version": 1, "tasks": []})
    print(f"state initialized at {state_dir}")


def save_yaml(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)


def estimate_context(tokens: int, long_context: int) -> bool:
    return tokens <= CONTEXT_ESTIMATE.get(long_context, 65536)


def capability_match(model: dict, requirements: dict) -> float:
    caps = model.get("capability", {})
    scored = []
    for dim, req in requirements.items():
        if req is None or req <= 0:
            continue
        if dim == "context":
            val = caps.get("long_context", 5)
        elif dim == "speed":
            val = model.get("speed", 5)
        elif dim == "tool_use":
            val = model.get("tool_calling", 5)
        else:
            val = caps.get(dim, 0)
        scored.append(min(val, req) / max(req, 1))
    if not scored:
        return 0.0
    return round(sum(scored) / len(scored) * 10, 2)


def success_history(perf: dict, model: str, category: str) -> float:
    rec = perf.get("records", {}).get(model, {})
    entries = rec.get("by_category", {}).get(category, [])
    if not entries:
        return 0.5  # neutral
    ok = sum(1 for e in entries if e.get("result") == "success")
    return round(ok / len(entries), 2)


def availability(model_state: dict, rpm_limit: int, pool: dict, pool_belongs: bool, now) -> float:
    if model_state.get("status") == "error":
        return 0.0
    if model_state.get("status") == "cooldown":
        until = model_state.get("cooldown_until")
        if until and until > now:
            return 0.0
        model_state["status"] = "healthy"
    if pool_belongs and pool and pool.get("used", 0) >= pool.get("limit", 1000):
        return 0.0
    used = model_state.get("used_minute", 0)
    if rpm_limit <= 0:
        return 1.0
    return round(max(0.0, 1.0 - used / rpm_limit), 2)


def paid_allowed(m: dict, priority: str, policies: dict, free_only: bool) -> bool:
    """cost:paid models: allowed at auto_allow_priority (policies.paid_models)
    or when free_only is globally off (explicit user override)."""
    if m.get("cost") != "paid":
        return True
    if not free_only:
        return True
    auto = policies.get("paid_models", {}).get("auto_allow_priority")
    return bool(auto) and priority == auto


def choose(profile: dict, models: dict, policies: dict, state_dir: Path):
    quota, perf, _ = load_state(state_dir)
    req = profile.get("requirements", {})
    category = profile.get("category", "general")
    risk = profile.get("risk", "medium")
    tokens = profile.get("tokens_estimated", 8000)
    priority = profile.get("priority", "normal")
    free_only = quota.get("free_only", policies.get("free_only", True))
    now = datetime.now(timezone.utc).isoformat()

    candidates = []
    for name, m in models.items():
        if not paid_allowed(m, priority, policies, free_only):
            continue
        cm = capability_match(m, req)
        if cm < policies.get("min_capability_match", 5.0):
            continue
        if not estimate_context(tokens, m.get("capability", {}).get("long_context", 5)):
            continue
        if profile.get("stage_needs_tools", True) and m.get("tool_calling", 5) < 7:
            continue
        candidates.append((name, m, cm))

    # twin resolution: prefer primary provider, flip to twin on pool exhaustion
    pool = quota.get("pools", {}).get("nvidia-day-1000", {})
    for name, m, cm in list(candidates):
        twin = m.get("twin")
        if not twin:
            continue
        if m.get("provider") == "nvidia" and pool.get("used", 0) >= pool.get("limit", 1000):
            tm = models.get(twin)
            if tm and not any(c[0] == twin for c in candidates):
                candidates.append((twin, tm, cm))

    scored = []
    for name, m, cm in candidates:
        ms = quota.get("models", {}).get(name, {})
        pool_belongs = m.get("quota_pool") == "nvidia-day-1000"
        avail = availability(ms, m.get("rpm_limit", 30), pool, pool_belongs, now)
        if avail <= 0:
            continue
        hist = success_history(perf, name, category)
        speed_n = m.get("speed", 5) / 10.0
        score = (cm * 0.4 + hist * 0.25 + speed_n * 0.15 + avail * 0.20)
        scored.append({
            "model": name,
            "id": m["id"],
            "provider": m.get("provider"),
            "capability_match": cm,
            "success_history": hist,
            "speed": m.get("speed"),
            "availability": avail,
            "score": round(score, 3),
        })

    scored.sort(key=lambda s: s["score"], reverse=True)

    budget = policies.get("budgets", {}).get("by_priority", {}).get(priority, 2)
    chain = scored[:budget]

    # promotion: if a tier is exhausted/failed, escalate from policies
    promo = policies.get("promotion", {}).get("tiers", {})
    promo_chain = []
    for tier in promo.values():
        for model in tier:
            if any(c["model"] == model for c in chain) and model not in promo_chain:
                promo_chain.append(model)
    for c in chain:
        if c["model"] not in promo_chain:
            promo_chain.append(c["model"])

    return {
        "profile": profile,
        "priority": priority,
        "budget": budget,
        "free_only": free_only,
        "chain": promo_chain[:max(budget, len(promo_chain))] if not chain else chain,
        "scores": scored,
    }


def debate(profile: dict, models: dict, policies: dict, state_dir: Path):
    """Pick independent debaters + a judge for multi-model debate.
    Debaters must be DIFFERENT models (twins are same-source, not independent).
    Judge comes from policies.debate.judge_models preference, else strongest
    available model not already debating."""
    quota, perf, _ = load_state(state_dir)
    req = profile.get("requirements", {})
    category = profile.get("category", "general")
    tokens = profile.get("tokens_estimated", 8000)
    priority = profile.get("priority", "normal")
    free_only = quota.get("free_only", policies.get("free_only", True))
    now = datetime.now(timezone.utc).isoformat()

    cfg = policies.get("debate", {})
    n_debaters = cfg.get("debaters", 2)
    rounds = cfg.get("rounds", 2)
    judge_pref = cfg.get("judge_models", [])
    pool = quota.get("pools", {}).get("nvidia-day-1000", {})

    candidates = []
    for name, m in models.items():
        if not paid_allowed(m, priority, policies, free_only):
            continue
        cm = capability_match(m, req)
        if cm < policies.get("min_capability_match", 5.0):
            continue
        if not estimate_context(tokens, m.get("capability", {}).get("long_context", 5)):
            continue
        if profile.get("stage_needs_tools", True) and m.get("tool_calling", 5) < 7:
            continue
        candidates.append((name, m, cm))

    scored = []
    for name, m, cm in candidates:
        ms = quota.get("models", {}).get(name, {})
        pool_belongs = m.get("quota_pool") == "nvidia-day-1000"
        avail = availability(ms, m.get("rpm_limit", 30), pool, pool_belongs, now)
        if avail <= 0:
            continue
        hist = success_history(perf, name, category)
        speed_n = m.get("speed", 5) / 10.0
        score = cm * 0.4 + hist * 0.25 + speed_n * 0.15 + avail * 0.20
        scored.append({
            "model": name,
            "id": m["id"],
            "provider": m.get("provider"),
            "capability_match": cm,
            "success_history": hist,
            "speed": m.get("speed"),
            "availability": avail,
            "score": round(score, 3),
        })
    scored.sort(key=lambda s: s["score"], reverse=True)

    # debaters: distinct models; skip a twin when its counterpart is picked
    debaters = []
    excluded = set()
    for s in scored:
        if len(debaters) >= n_debaters:
            break
        name = s["model"]
        if name in excluded:
            continue
        debaters.append(s)
        excluded.add(name)
        twin = models[name].get("twin")
        if twin and twin in models:
            excluded.add(twin)

    picked = {d["model"] for d in debaters}
    judge = None
    for jn in judge_pref:
        if jn not in models or jn in picked:
            continue
        m = models[jn]
        if not paid_allowed(m, priority, policies, free_only):
            continue
        ms = quota.get("models", {}).get(jn, {})
        pool_belongs = m.get("quota_pool") == "nvidia-day-1000"
        if availability(ms, m.get("rpm_limit", 30), pool, pool_belongs, now) > 0:
            judge = jn
            break
    if judge is None:
        for s in scored:
            if s["model"] not in picked:
                judge = s["model"]
                break

    judge_info = None
    if judge:
        m = models[judge]
        judge_info = {"model": judge, "id": m["id"], "provider": m.get("provider")}

    return {
        "profile": profile,
        "mode": "debate",
        "min_candidates": n_debaters + 1,
        "debaters": debaters,
        "judge": judge_info,
        "rounds": rounds,
        "free_only": free_only,
        "scores": scored,
    }


def record(outcome: dict, models: dict, policies: dict, state_dir: Path):
    quota, perf, history = load_state(state_dir)
    now = datetime.now(timezone.utc).isoformat()
    model = outcome.get("model")
    result = outcome.get("result", "unknown")
    category = outcome.get("category", "general")
    ms = quota.setdefault("models", {}).setdefault(model, {
        "used_minute": 0, "failures": 0, "status": "healthy", "cooldown_until": None,
    })

    if result == "success":
        ms["used_minute"] = ms.get("used_minute", 0) + 1
        ms["failures"] = 0
        ms["status"] = "healthy"
        ms["cooldown_until"] = None
        pool = quota.get("pools", {}).get("nvidia-day-1000")
        m = models.get(model, {})
        if pool and m.get("provider") == "nvidia":
            pool["used"] = pool.get("used", 0) + 1
    elif result in ("rate_limit", "quota"):
        ms["failures"] = ms.get("failures", 0) + 1
        if ms["failures"] >= 2:
            ms["status"] = "cooldown"
            ms["cooldown_until"] = now
            # cooldown 10m
            from datetime import timedelta
            ms["cooldown_until"] = (datetime.now(timezone.utc) + timedelta(minutes=10)).isoformat()
        else:
            ms["status"] = "warning"
    elif result in ("timeout", "upstream"):
        ms["failures"] = ms.get("failures", 0) + 1
        if ms["failures"] >= 3:
            ms["status"] = "cooldown"
            ms["cooldown_until"] = (datetime.now(timezone.utc) + __import__("datetime").timedelta(minutes=10)).isoformat()
    elif result in ("auth", "not_found", "permanent"):
        ms["status"] = "error"

    save_yaml(state_dir / "quota.yaml", quota)

    # memory
    if outcome.get("rating") is not None or result == "success":
        rec = perf.setdefault("records", {}).setdefault(model, {"by_category": {}})
        entries = rec["by_category"].setdefault(category, [])
        entries.append({
            "task": outcome.get("task", ""),
            "result": result,
            "rating": outcome.get("rating"),
            "tokens": outcome.get("tokens"),
            "ts": now,
        })
        entries[:] = entries[-200:]
        save_json(state_dir / "memory" / "model-performance.json", perf)

    history.setdefault("tasks", []).append({
        "task": outcome.get("task", ""),
        "category": category,
        "model": model,
        "result": result,
        "tokens": outcome.get("tokens"),
        "rating": outcome.get("rating"),
        "ts": now,
    })
    history["tasks"][:] = history["tasks"][-500:]
    save_json(state_dir / "memory" / "task-history.json", history)

    print(f"recorded {model} -> {result} (category={category})")


def main():
    ap = argparse.ArgumentParser(description="Free-Model Delegate scheduler")
    ap.add_argument("--profile", help="path to task profile JSON")
    ap.add_argument("--debate", help="path to task profile JSON (multi-model debate mode)")
    ap.add_argument("--record", help="path to outcome JSON")
    ap.add_argument("--init", action="store_true", help="initialize state files")
    ap.add_argument("--self-check", action="store_true", help="validate configs")
    ap.add_argument("--history", nargs=2, metavar=("MODEL", "CATEGORY"),
                    help="print success-rate for a model+category")
    ap.add_argument("--skill-dir", default=str(SKILL_DIR))
    ap.add_argument("--state-dir", default=str(DEFAULT_STATE_DIR))
    args = ap.parse_args()

    skill_dir = Path(args.skill_dir)
    state_dir = Path(args.state_dir)
    models = load_yaml(skill_dir / "models.yaml").get("models", {})
    policies = load_yaml(skill_dir / "policies.yaml")

    if args.init:
        init_state(state_dir, models, policies)
        return 0
    if args.self_check:
        ok = True
        missing = [n for n, m in models.items() if "id" not in m]
        if missing:
            print(f"models missing id: {missing}")
            ok = False
        dupes = [n for n, m in models.items() if m.get("twin") and m["twin"] not in models]
        if dupes:
            print(f"twin refs missing: {dupes}")
            ok = False
        print(f"models: {len(models)}")
        print("self-check:", "OK" if ok else "FAILED")
        return 0 if ok else 1
    if args.history:
        model, category = args.history
        _, perf, _ = load_state(state_dir)
        print(success_history(perf, model, category))
        return 0
    if args.profile:
        profile = load_json(Path(args.profile))
        res = choose(profile, models, policies, state_dir)
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    if args.debate:
        profile = load_json(Path(args.debate))
        res = debate(profile, models, policies, state_dir)
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    if args.record:
        outcome = load_json(Path(args.record))
        record(outcome, models, policies, state_dir)
        return 0

    print("no action. use --init / --self-check / --profile / --record / --history",
          file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main())