#!/usr/bin/env python3
"""extract.py — deterministic JSON / confidence-envelope extraction for the
Free-Model Delegate skill.

WHY THIS FILE EXISTS
--------------------
Delegated models follow the JSON output contract probabilistically, not
deterministically. Agents that hand-roll extraction each time keep tripping
the same two bugs:
  1. `json.dumps(extract_json(x)) or x` — json.dumps(None) returns the string
     "null", which is truthy, so the fallback never runs and the literal text
     "null" is passed onward as a proposal/envelope.
  2. Strict parsing that rejects valid output where the JSON is embedded in
     free text (e.g. "Here is my proposal: {...}").

ALWAYS use the functions here (import or CLI) instead of writing extraction
logic inline.

Contract:
  extract_json(text)       -> dict/list | None   (None = not parseable)
  extract_envelope(text)   -> dict               (never None; defaults on loss)
"""

import argparse
import json
import re
import sys
from typing import Any, Optional

# Stage output contracts (agents/*.md). Each contract names the key(s) that
# carry the stage artifact. Pass the right one explicitly; the default is the
# regular stage contract ("answer") — NOT a lenient superset, so a regular
# stage emitting a judge-shaped envelope is flagged as a violation, and a
# debater's "proposal" output is never misread as an answer.
CONTRACTS = {
    "stage": ("answer",),
    "judge": ("decision",),
    "debater": ("proposal",),
}


def _valid_conf(v: Any) -> bool:
    """True when the value is usable as a confidence number."""
    if v is None:
        return False
    try:
        float(v)
        return True
    except (TypeError, ValueError):
        return False


def extract_json(text: Any) -> Optional[Any]:
    """Best-effort parse of a JSON object/list from model output.

    Fallback ladder:
      1. whole text parses as JSON
      2. JSONDecoder.raw_decode() at each '{' — string/escape-aware, so
         braces inside string values ("use } careful") never break the match
         (handles prose around JSON)
      3. fenced ```json ... ``` code block
    Returns None when nothing parseable is found. Never returns the string
    "null" — a literal JSON `null` also becomes None (same semantics).
    """
    if text is None:
        return None
    if not isinstance(text, str):
        text = str(text)

    stripped = text.strip()
    if not stripped:
        return None

    # 1. whole-text parse
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass

    # 2. raw_decode at each '{' (CPython scanner: string/escape aware)
    dec = json.JSONDecoder()
    for i, ch in enumerate(stripped):
        if ch != "{":
            continue
        try:
            obj, _ = dec.raw_decode(stripped, i)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, (dict, list)):
            return obj

    # 3. fenced json code block
    m = re.search(r"```(?:json)?\s*\n([\s\S]*?)\n```", text)
    if m:
        try:
            return json.loads(m.group(1).strip())
        except json.JSONDecodeError:
            pass

    return None


def extract_envelope(text: Any, answer_keys=CONTRACTS["stage"]) -> dict:
    """Parse a confidence envelope; degrade safely instead of raising.

    `answer_keys` names the field(s) that carry the stage artifact — pass the
    matching contract explicitly: CONTRACTS["stage"] ("answer",), CONTRACTS
    ["judge"] ("decision",), CONTRACTS["debater"] ("proposal",). The default
    is strict (regular stage contract only), so contract mixing is flagged
    rather than silently accepted.

    Defaults (per orchestrator.md confidence contract):
      confidence -> 0.0, risk -> "unknown", need_review -> True
    `need_review` defaults to False only when the "decision" key was hit
    (judge verdicts are the terminal quality gate); every other contract
    defaults to review-required. Explicit `need_review` wins over defaults,
    and any format violation forces review.

    Flags `format_violation: True` when confidence is missing/invalid or no
    answer key carried a non-empty value. The raw model output is echoed back
    in the `raw` field so downstream never loses the original text (SKILL.md
    format-violation protocol relies on it). `raw` is for hand-off/debugging
    ONLY — do NOT persist it into --record or state files.
    """
    raw = text if isinstance(text, str) else ""
    parsed = extract_json(text)
    if not isinstance(parsed, dict):
        return {
            "answer": raw,
            "confidence": 0.0,
            "risk": "unknown",
            "need_review": True,
            "format_violation": True,
            "raw": raw,
        }
    conf = parsed.get("confidence")
    try:
        conf = float(conf) if _valid_conf(conf) else 0.0
    except (TypeError, ValueError):
        conf = 0.0
    conf = max(0.0, min(1.0, conf))
    risk = parsed.get("risk")
    if risk not in ("low", "medium", "high"):
        risk = "unknown"
    hit = [k for k in answer_keys
           if k in parsed and parsed[k] is not None and parsed[k] != ""]
    need = parsed.get("need_review")
    if need is None:
        # Only a hit on the judge contract key ("decision") is terminal;
        # debater proposals and regular answers default to review-required.
        need = "decision" not in hit
    elif isinstance(need, str):
        # Models often emit "false"/"true" as STRINGS (not booleans). Parse
        # the explicit falsy literals; anything ambiguous stays truthy
        # (conservative: over-review, never skip).
        need = need.strip().lower() not in ("false", "0", "no")
    has_confidence = "confidence" in parsed and _valid_conf(parsed["confidence"])
    has_answer = bool(hit)
    violation = not has_confidence or not has_answer
    if violation:
        need = True
    return {
        "answer": next((parsed[k] for k in hit), ""),
        "confidence": conf,
        "risk": risk,
        "need_review": bool(need),
        "format_violation": bool(violation),
        "raw": raw,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--json", help="path to a file whose content is model output")
    ap.add_argument("--envelope", help="path to a file whose content is model output")
    ap.add_argument("--text", help="inline model output string")
    grp = ap.add_mutually_exclusive_group()
    grp.add_argument("--judge", action="store_true",
                     help="enforce the judge contract: artifact key = "
                          "'decision' ONLY")
    grp.add_argument("--debater", action="store_true",
                     help="enforce the debater contract: artifact key = "
                          "'proposal' ONLY")
    args = ap.parse_args()

    if args.json and args.envelope:
        print("use only one of --json / --envelope", file=sys.stderr)
        return 2
    if args.envelope:
        path = args.envelope
        text = open(path, encoding="utf-8-sig").read() if path != "-" else sys.stdin.read()
        keys = CONTRACTS["judge"] if args.judge else \
               CONTRACTS["debater"] if args.debater else CONTRACTS["stage"]
        print(json.dumps(extract_envelope(text, answer_keys=keys),
                         ensure_ascii=False, indent=2))
        return 0
    if args.json:
        path = args.json
        text = open(path, encoding="utf-8-sig").read() if path != "-" else sys.stdin.read()
    else:
        text = args.text or ""
    parsed = extract_json(text)
    if parsed is None:
        print("null", flush=True)
        return 1
    print(json.dumps(parsed, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
