---
name: free-model-delegate
description: Auto-delegate coding and research tasks to free-tier opencode models via a quota-aware AI scheduler. Trigger automatically on repetitive/mechanical/batch work (multi-file refactors, boilerplate, regex sweeps, test-fixing loops, doc generation) and on explicit requests for free models or named endpoints (GLM-5.2, Nemotron Free, MiniMax M3, big-pickle, deepseek-v4-flash-free, nvidia/*, "用免费模型", offload to opencode). Classifies the task, routes through capability/quota/health filters, and runs `opencode run` with timeout + retry + fallback. Never triggers on one-off trivial questions.
license: MIT
compatibility: claude-code, opencode
metadata:
  audience: developers
  workflow: free-tier-llm-scheduler
---

# Free-Model Delegate — AI Router

Schedules coding/research tasks onto free LLMs (NVIDIA build.nvidia.com +
OpenCode Zen free tier) through `opencode run`. Treats the free pool as an
unstable capacity pool: capability, context, tool-calling, rate limits, and
circuit-breaker health all feed the routing decision.

## Architecture (3 files)

| File | Role |
|---|---|
| `SKILL.md` (this) | Trigger policy + execution loop |
| `scheduler.md` (same dir) | Routing engine: task profile, 5 filters, scoring, quota/circuit breaker, multi-agent stages, routing tables |
| `models.yaml` (same dir) | Model capability database (verified IDs) |

**On trigger, load `scheduler.md` and `models.yaml` from this skill's directory
before doing anything else.**

## When to trigger

**AUTO-TRIGGER (no explicit ask needed)** — repetitive, mechanical, high-volume:

- batch edits / refactors across many files, boilerplate/scaffolding generation
- regex / find-and-replace sweeps, mechanical test-fixing loops
- doc / comment / README / changelog generation
- running the same shape of task repeatedly (per-module, per-file)
- long-running background work that doesn't need expensive judgment

For auto-triggered repetitive work the scheduler defaults to a flash model.

**EXPLICIT trigger** — user asks for it:

- "用免费模型", "免费 AI", "free model", "用免费的"
- "offload", "delegate to opencode", "交给 opencode 跑"
- names a free endpoint: GLM-5.2, Nemotron Free, MiniMax M3, big-pickle,
  deepseek-v4-flash-free, nvidia/*

Do NOT trigger on implicit signals alone (cost concerns, "省点钱", performance
complaints) — confirm with the user first. Do NOT trigger on one-off trivial
questions or short clarifications.

## Execution flow (every delegation)

1. **Analyze** — build the Task Profile per scheduler.md §1 (category,
   requirements, risk, tokens, priority). Budget comes from priority.
2. **Schedule** — run scheduler.md §2-4: filters, twin resolution, scoring.
   Result: an ordered chain of models, length ≤ budget.
3. **Execute** — run the loop below with the chain. The loop retries transient
   failures and falls down the chain; it never exceeds the chain.
4. **Record** — update quota state per scheduler.md §3 (success/429/5xx/4xx
   outcomes). Cooldowns and pool counters persist for the next delegation.
5. **Report** — surface the final answer AND one line on the routing decision
   ("→ deepseek_v4_flash, capability 9.0, quota 90%").

## Execution loop

Wrap every delegation in this loop (bash). It applies per-attempt timeout,
exponential backoff, error classification, and chain fallback.

```bash
WORKDIR="/path/to/project"
PROMPT="Add a /healthz endpoint that returns {status:'ok'}"
TIMEOUT_SECS=600            # wall-clock cap per attempt
# Chain comes from the scheduler (task-aware order, budget-capped).
MODELS=(
  "nvidia/deepseek-ai/deepseek-v4-flash"
  "nvidia/minimaxai/minimax-m3"
  "nvidia/z-ai/glm-5.2"
  "opencode/deepseek-v4-flash-free"
  "opencode/big-pickle"
  "opencode/nemotron-3-ultra-free"
  "opencode/hy3-free"
)
MAX_ATTEMPTS=2              # retries per model before moving on
BASE_BACKOFF=2              # seconds; doubles each attempt (2s, 4s, …)

attempt_total=0
for model in "${MODELS[@]}"; do
  for attempt in $(seq 1 $MAX_ATTEMPTS); do
    attempt_total=$((attempt_total+1))
    echo "→ [$model] attempt $attempt (overall #$attempt_total)" >&2

    out=$(timeout "$TIMEOUT_SECS" opencode run \
        --auto --dir "$WORKDIR" --model "$model" --format json \
        "$PROMPT" 2>&1)
    code=$?

    # Success — extract final assistant text from nd-JSON stream
    if [ $code -eq 0 ]; then
      answer=$(echo "$out" | jq -r 'select(.type=="text") | .part.text // empty' \
               | tail -1)
      if [ -n "$answer" ]; then
        printf '%s\n' "$answer"
      else
        echo "$out"   # fall back to raw stream if no text event found
      fi
      exit 0
    fi

    # Classify the failure
    if [ $code -eq 124 ]; then
      reason="timeout after ${TIMEOUT_SECS}s"
      transient=true
    elif echo "$out" | grep -qiE '429|rate.?limit|quota|too.?many.?requests|exceeded'; then
      reason="rate limit / quota"
      transient=true
    elif echo "$out" | grep -qiE '\b(5[0-9]{2}|502|503|504)\b|connection.?reset|upstream.?timeout|bad.?gateway|service.?unavailable'; then
      reason="upstream 5xx / network"
      transient=true
    elif echo "$out" | grep -qiE '\b(401|403|404)\b|unauthor|invalid.?api.?key|model.?not.?found|forbidden'; then
      reason="auth / not-found (permanent)"
      transient=false
    else
      reason="unknown (exit $code)"
      transient=true
    fi

    echo "  ✗ [$model] $reason" >&2

    if [ "$transient" = false ]; then
      break   # skip this model entirely
    fi
    if [ $attempt -lt $MAX_ATTEMPTS ]; then
      sleep $((BASE_BACKOFF ** attempt))
    fi
  done
done

echo "All models in chain exhausted after $attempt_total attempts" >&2
exit 1
```

### PowerShell port (native Windows, non-Git-Bash)

```powershell
$WORKDIR  = "C:\path\to\project"
$PROMPT   = "Add a /healthz endpoint that returns {status:'ok'}"
$TIMEOUT  = 600   # seconds
$MODELS   = @('nvidia/deepseek-ai/deepseek-v4-flash','nvidia/minimaxai/minimax-m3','nvidia/z-ai/glm-5.2','opencode/deepseek-v4-flash-free','opencode/big-pickle','opencode/nemotron-3-ultra-free','opencode/hy3-free')
$MAX      = 2
$BACKOFF  = 2

foreach ($model in $MODELS) {
  for ($a = 1; $a -le $MAX; $a++) {
    Write-Host "→ $model attempt $a"
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'opencode'
    $psi.ArgumentList.Add('run'); $psi.ArgumentList.Add('--auto')
    $psi.ArgumentList.Add('--dir'); $psi.ArgumentList.Add($WORKDIR)
    $psi.ArgumentList.Add('--model'); $psi.ArgumentList.Add($model)
    $psi.ArgumentList.Add('--format'); $psi.ArgumentList.Add('json')
    $psi.ArgumentList.Add($PROMPT)
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError  = $true
    $psi.UseShellExecute = $false
    $p = [System.Diagnostics.Process]::Start($psi)
    $exited = $p.WaitForExit($TIMEOUT * 1000)
    if (-not $exited) { $p.Kill(); $code = 124 } else { $code = $p.ExitCode }
    $out = $p.StandardOutput.ReadToEnd() + $p.StandardError.ReadToEnd()

    if ($code -eq 0) {
      $last = ($out -split "`n" | Where-Object { $_ -match '"type"\s*:\s*"text"' } | Select-Object -Last 1)
      if ($last) { ($last | ConvertFrom-Json).part.text } else { $out }
      return
    }

    $transient = $true
    if ($code -eq 124)                       { $reason = "timeout" }
    elseif ($out -match '429|rate.?limit|quota|exceeded') { $reason = "rate limit / quota" }
    elseif ($out -match '5\d\d|connection.?reset|upstream') { $reason = "upstream" }
    elseif ($out -match '401|403|404|unauthor|invalid.?key|model.?not.?found') { $reason = "permanent"; $transient = $false }
    else                                      { $reason = "unknown exit $code" }

    Write-Host "  ✗ $model $reason"
    if (-not $transient) { break }
    if ($a -lt $MAX) { Start-Sleep -Seconds ([math]::Pow($BACKOFF, $a)) }
  }
}
Write-Error "All models in chain exhausted"
exit 1
```

## Multi-turn continuation

Reuse a session to keep context across stages or runs:

```bash
SESSION=$(opencode run --auto --dir . --model opencode/big-pickle --format json \
  "List the failing tests in tests/" 2>&1 | jq -r 'select(.type=="session") | .sessionID' | head -1)

opencode run --auto --dir . --model opencode/big-pickle --format json \
  -s "$SESSION" "Fix the first failure"
```

## One-time setup

```bash
# NVIDIA provider — key from https://build.nvidia.com
opencode auth login -p nvidia

# OpenCode Zen — key from https://opencode.ai/auth
# Inside TUI: /connect -> OpenCode Zen -> paste key
```

Verify: `opencode auth list`, `opencode models nvidia --refresh`,
`opencode models opencode --refresh`. Quota state file is created on first run
at `~/.config/free-model-delegate/state.yaml` (see scheduler.md §3).

## Guardrails recap

- **free_only: true** — never touch `cost: paid` models without explicit user approval.
- **Budget is a hard cap** — priority low=1 / normal=2 / critical=4 distinct models per task.
- **Layered timeouts** — inner `timeout` ≤ outer Bash-tool timeout, or the loop gets killed mid-flight.
- **`--auto` grants full bash+edit power in `--dir`** — sanity-check `--dir`.
- **Free-tier data retention** — no secrets, tokens, or PII into free endpoints.
- **Record outcomes** — quota state is the memory; without it the scheduler is blind.
