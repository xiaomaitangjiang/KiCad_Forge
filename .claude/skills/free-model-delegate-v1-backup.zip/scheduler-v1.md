# Scheduler Engine — AI Router for Free-Model Delegate

This file is the routing brain. Load it together with `models.yaml` whenever the
skill triggers. It converts a user request into a Task Profile, filters the
model database through five gates, scores the survivors, and returns an ordered
model chain to execute.

## 0. Pipeline overview

```
user request
   │
   ▼
Task Analyzer ──► Task Profile (category, requirements, risk, tokens, priority)
   │
   ▼
Capability Filter    ── models that can do the job (score ≥ threshold)
Context Filter       ── models whose context fits the estimated tokens
Tool Support Filter  ── models with enough tool_calling for agentic stages
Rate Limit Filter    ── models with quota remaining, not in cooldown
Health Filter        ── circuit breaker states
   │
   ▼
Scoring: score = capability_match × 0.5 + availability × 0.3 + speed_norm × 0.2
   │
   ▼
Ordered model chain (length capped by task budget)
   │
   ▼
SKILL.md execution loop (timeout + retry + fallback along the chain)
   │
   ▼
Record outcome back into quota state (success / 429 / 5xx / 4xx)
```

## 1. Task Analyzer

Do NOT map keywords to models. Produce a Task Profile instead:

```yaml
task:
  category: coding.bugfix        # from the classification tree
  requirements:                  # 0-10 each; only set dims that matter
    reasoning: 8
    coding: 9
    context: 7
    speed: 6
    tool_use: 8
  risk: medium                   # low | medium | high
  tokens_estimated: 12000        # guess from repo size + task breadth
  priority: normal               # low | normal | critical
```

Requirements map onto model capability dims: `coding → coding`, `reasoning →
reasoning`, `context → long_context/repository`, `speed → speed`,
`tool_use → tool_calling/agent`.

### Classification tree

```
Coding
├── New Feature        (design + implementation)
├── Bug Fix            (diagnose + fix + verify)
├── Refactor           (mechanical or structural)
├── Review             (normal vs high-risk)
├── Test               (generate / fix test suites)
└── Documentation      (docs, comments, README, changelog)

Reasoning
├── Architecture
├── Algorithm
└── Security

Analysis
├── Logs
├── Repository         (large-codebase analysis)
└── Requirements
```

### Priority → budget

| Priority | max_models | When |
|---|---|---|
| low | 1 | simple edit, rename, typo fix, one-file doc |
| normal | 2 | most bugfixes, features, tests |
| critical | 4 | architecture, security review, repo analysis |

Budget counts distinct models consumed by the whole task (all stages).
Never exceed it — a rename must not burn Nemotron Ultra + Kimi + DeepSeek.

## 2. Capability match

For each model in `models.yaml`, compute the match against the task profile:

```
capability_match = mean over required dims of model.capability[dim]
                  (missing dim treated as 0 unless task dim is unset)
```

- `capability_match < 5` → drop (Capability Filter)
- `tokens_estimated > model context` → drop (Context Filter). Approximate
  context from `long_context`: < 6 → ~16K, 6-7 → ~64K, 8 → ~128K, 9-10 → ~256K+
- Stage needs tool execution and `tool_calling < 7` → drop (Tool Support Filter).
  Pure Q&A / planning stages may ignore this gate.
- Cooldown or rate-limit blocked → drop (Rate Limit + Health Filters).

### Twin handling

Some models exist on both pools (e.g. `nemotron_ultra` = NVIDIA 550B,
`nemotron_ultra_zen` = Zen free, same capability). Treat the NVIDIA twin as
primary while `nvidia-day-1000` quota remains; flip to the Zen twin when the
NVIDIA pool is exhausted (tracked in quota state). Never count both toward
budget — they are the same capability.

## 3. Quota state & circuit breaker

State lives in a YAML file the agent reads/writes between runs:

```
Path:  $FMD_STATE_FILE if set, else ~/.config/free-model-delegate/state.yaml
       (PowerShell: $HOME\.config\free-model-delegate\state.yaml)
```

### Schema

```yaml
version: 1
free_only: true                 # false only if user explicitly allows paid models
pools:
  nvidia-day-1000:
    limit: 1000
    used: 0
models:
  nemotron_ultra:
    used_minute: 0
    failures: 0                 # consecutive 429s
    status: healthy             # healthy | warning | cooldown | error
    cooldown_until: null        # ISO-8601 timestamp
```

### Update rules (record after every delegation)

| Outcome | Update |
|---|---|
| success | `used_minute += 1`; `failures = 0`; `status = healthy`; pool `used += 1` |
| 429 / quota | `failures += 1`; if `failures == 1` → `status = warning`; if `failures >= 2` → `status = cooldown`, `cooldown_until = now + 10m`; pool `used` stays (NVIDIA 429 is global) |
| 5xx / timeout | `failures += 1`; cooldown only after 3 consecutive |
| 401 / 403 / 404 | `status = error` (bad key or model retired — user must fix; do not retry) |

When `status = cooldown` and `cooldown_until > now` → availability = 0.
When `status = error` → model removed until user fixes auth.
When pool `used >= limit` → all `quota_pool: nvidia-day-1000` models get
availability 0; the scheduler falls back to Zen twins / other pools.

### Circuit breaker state machine

```
HEALTHY ──1× 429──► WARNING ──2nd consecutive 429──► COOLDOWN (10m)
   ▲                                                     │
   └───────────── success resets ────────────────────────┘
ERROR: 401/403/404 → permanent until user re-auths
```

## 4. Scoring

After filtering, rank survivors:

```
score = capability_match × 0.5 + availability × 0.3 + speed_norm × 0.2
availability = 0 if cooldown/error/rate-limited
               else max(0, 1 − used_minute / rpm_limit)
speed_norm   = model.speed / 10
```

Example (task: debugging, requirements `coding 9 debugging 9`):

| Model | capability_match | availability | speed_norm | score |
|---|---|---|---|---|
| deepseek_v4_flash | 9.0 | 0.9 (36/40 used) | 1.0 | 4.50+0.27+0.20 = **4.97** |
| nemotron_ultra | 8.0 | 0.1 (18/20 used) | 0.4 | 4.00+0.03+0.08 = 4.11 |

→ DeepSeek wins despite lower capability: quota-aware routing works.

## 5. Multi-agent stages (complex tasks)

For `critical` tasks (or anything with a natural plan→code→verify shape),
run sequential stages. Each stage re-enters the scheduler for its role and
consumes budget.

```
Planner ──► Coder ──► Tester ──► Reviewer
```

### Stage templates (role → preferred candidates)

| Task | Stage 1 | Stage 2 | Stage 3 | Stage 4 |
|---|---|---|---|---|
| New Feature | Planner: big_pickle | Coder: deepseek_v4_flash | Tester: hy3 | Reviewer: nemotron_ultra |
| Bug Fix | Investigator: laguna | Fixer: deepseek_v4_flash | Verifier: big_pickle | — |
| Architecture | nemotron_ultra | big_pickle | nemotron_super | deepseek_v4_pro |
| Repo analysis | kimi_k2* | laguna | nemotron_ultra | big_pickle |
| Code review (normal) | nemotron_lightning | deepseek_v4_flash | — | — |
| Code review (high-risk: crypto/db/kernel/concurrency) | nemotron_ultra | big_pickle | — | — |
| Docs | mimo | qwen_coder | hy3 | — |
| Simple edit | hy3 | mimo | — | — |

\* `kimi_k2` is **paid** — with `free_only: true` replace it by
`laguna` → `nemotron_ultra` → `big_pickle` for repo analysis.

Each stage:
1. Runs through the scheduler (filters + scoring) restricted to the stage's
   candidate list.
2. Executes via the SKILL.md loop.
3. Feeds its final text into the next stage's prompt.
4. Decrements the task budget (distinct models). Budget exhausted → reuse the
   last stage's model, or stop and hand a summary to the user.

## 6. Routing tables (quick reference)

| Task | Primary | Backup | Notes |
|---|---|---|---|
| Architecture design | nemotron_ultra | big_pickle | critical budget |
| Complex algorithm | nemotron_ultra | big_pickle | |
| Write code | deepseek_v4_flash | nemotron_lightning | |
| Bug fix | deepseek_v4_flash | laguna | |
| Log analysis | laguna | nemotron_super | |
| Large repo | laguna (or kimi_k2 if paid allowed) | nemotron_ultra | |
| Code review | big_pickle | nemotron_ultra | high-risk → swap order |
| Test generation | deepseek_v4_flash | hy3 | |
| Documentation | mimo | qwen_coder | |
| Simple edit | hy3 | mimo | low budget, 1 model |
| Repetitive batch (AUTO) | deepseek_v4_flash | deepseek_v4_flash_zen | quota twin |

## 7. Guardrails

- **free_only: true by default.** Never select `cost: paid` models unless the
  user explicitly approves. Say so and ask.
- **Budget is a hard cap.** Track distinct models used; refuse to exceed.
- **NVIDIA pool exhaustion is global.** If `nvidia-day-1000.used ≥ 1000`,
  the whole nvidia pool is unavailable until the next day — route to Zen
  twins without trying NVIDIA first.
- **Never retry a model in `error` state.**
- **Report the score.** When surfacing the plan to the user, show which model
  was picked and why (capability match, quota state) — one line is enough.
